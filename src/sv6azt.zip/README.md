# simple-Angular-App

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/sv6azt)